package main

import (
	"fmt"
	"io/ioutil"
	"math/rand"
	"net/http"
	"strings"
	"time"
)

func main() {
	resp, err := http.Get("https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all")
	if err != nil {
		fmt.Println("Bot : Proxy err!")
	}
	defer resp.Body.Close()
	proxyBytes, _ := ioutil.ReadAll(resp.Body)
	proxyList := strings.Split(string(proxyBytes), "\n")
	rand.Seed(time.Now().UnixNano())
	randomIndex := rand.Intn(len(proxyList))
	px := proxyList[randomIndex]
	fmt.Println(px)
}
