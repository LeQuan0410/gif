# Flyier-DoS
Flyier is a very powerful and effective DoS/DDoS written in Python. 


# Installation

On linux:

$ git clone https://github.com/zSodex/Flyier-DoS

$ cd Flyier-DoS

$ pip3 install -r requirements.txt

$ python3 main.py 



# Interface 


<img width="581" alt="flyier" src="https://user-images.githubusercontent.com/109610184/230609652-75421bb2-903d-4ac4-b13f-ad315c065c14.png">




# Flyier Attack 𓆰

<img width="679" alt="turnedoff" src="https://user-images.githubusercontent.com/109610184/230609697-d764eef3-613f-44be-b7fe-1b70d5baac13.png">



Contact me on discord if you have any issue: @zSodex#3828
